package TextComposition;

import java.util.LinkedHashMap;

public interface Compositor {
    public void compose(LinkedHashMap<Integer, Component> components);
}
